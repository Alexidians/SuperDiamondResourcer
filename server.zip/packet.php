<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://alexidians.com");
header("Access-Control-Allow-Headers: *");

// Function to return error response
function returnError($errorCode) {
    echo json_encode(["success" => false, "errorcode" => $errorCode]);
    logMessage("Packet Request Failed: " . $errorCode);
    exit;
}

// Function to initialize player data and write it to file
function initializePlayerData($playerdataFile) {
    $playerdata = array(
        "coins" => 0,
        "wood" => 0,
        "stone" => 0,
        "crops" => 0,
        "sand" => 0,
        "leaves" => 0,
        "fish" => 0,
        "axelevel" => 1,
        "pickaxelevel" => 1,
        "hoelevel" => 1,
        "shovellevel" => 1,
        "shearslevel" => 1,
        "fishingrodlevel" => 1,
    );
    if (file_put_contents($playerdataFile, json_encode($playerdata)) === false) {
        returnError("ERR_FILE_WRITE_FAILED");
    }
    return $playerdata;
}

// Get input data
$input = json_decode(file_get_contents("php://input"), true);

if (!$input) {
    returnError("ERR_INVALID_INPUT_JSON");
}

$token = $input["token"] ?? null;
$username = $input["username"] ?? null;
$identifier = $input["identifier"] ?? null;

if (!$token || !$username || !$identifier) {
    returnError("ERR_MISSING_PARAMETERS");
}

include("verify.php");

$playerdataFile = "playerdata/" . $identifier . ".json";

if (file_exists($playerdataFile)) {
    $playerdata = json_decode(file_get_contents($playerdataFile), true);
    if ($playerdata === null) {
        // If JSON decoding fails, initialize player data
        $playerdata = initializePlayerData($playerdataFile);
    }
} else {
    // If file does not exist, initialize player data
    $playerdata = initializePlayerData($playerdataFile);
}

$upgradeprices = json_decode(file_get_contents("config/upgradeprices.json"), true);
if ($upgradeprices === null) {
    returnError("ERR_CONFIG_READ");
}

$packet = $playerdata;
$packet["upgradeaxeprice"] = $upgradeprices["axe"] * ($playerdata["axelevel"] + $playerdata["axelevel"]);
$packet["upgradepickaxeprice"] = $upgradeprices["pickaxe"] * ($playerdata["pickaxelevel"] + $playerdata["pickaxelevel"]);
$packet["upgradehoeprice"] = $upgradeprices["hoe"] * ($playerdata["hoelevel"] + $playerdata["hoelevel"]);
$packet["upgradeshovelprice"] = $upgradeprices["shovel"] * ($playerdata["shovellevel"] + $playerdata["shovellevel"]);
$packet["upgradeshearsprice"] = $upgradeprices["shears"] * ($playerdata["shearslevel"] + $playerdata["shearslevel"]);
$packet["upgradefishingrodprice"] = $upgradeprices["fishingrod"] * ($playerdata["fishingrodlevel"] + $playerdata["fishingrodlevel"]);
$packet["success"] = true;
$packet["mod"] = false;

$dir = "modifiers/packet";
$files = scandir($dir);
foreach ($files as $file) {
    if ($file != '.' && $file != '..' && is_file($dir . '/' . $file)) {
        include($dir . '/' . $file);
    }
}

echo json_encode($packet);
?>
