<?php
// Define constants for file paths
define('CONFIG_DIR', 'config/');
define('DATA_DIR', 'data/');
define('LOGS_DIR', 'logs/');

// Function to read JSON configuration files
function readJsonConfig($filename) {
    $filePath = CONFIG_DIR . $filename;
    if (file_exists($filePath)) {
        $json = file_get_contents($filePath);
        return json_decode($json, true);
    } else {
        // Handle file not found error
        return null;
    }
}

// Function to log messages
function logMessage($text) {
    // Get the current date and time
    $dateTime = date("j M Y H:i");

    // Read the log file name from "data/logfile.txt"
    $logfile = file_get_contents(DATA_DIR . "logfile.txt");

    // Check if logfile is empty or not
    if (empty($logfile)) {
        // Handle empty logfile error
        return false;
    }

    // Format the log message
    $logMessage = "[$dateTime] $text\n";

    // Append the log message to the specified log file
    $logFilePath = LOGS_DIR . $logfile . ".log";
    file_put_contents($logFilePath, $logMessage, FILE_APPEND | LOCK_EX);

    // Read logging configuration
    $logConfig = readJsonConfig("logger.json");

    // Check if server logging is enabled
    if ($logConfig !== null && isset($logConfig["serverlog"]) && $logConfig["serverlog"]) {
        // Log to the PHP error log
        error_log($logMessage);
    }

    return true;
}
?>
