<?php
function generateFormattedDate($timestamp) {
    return date("j M Y H:i", $timestamp);
}

include("helper.php");
$onlinedata = json_decode(file_get_contents("online.json"), true);
if (!$onlinedata["online"]) {
    echo json_encode(array(
        'success' => false,
        'errorcode' => "ERR_SERVER_OFFLINE"
    ));
    exit();
}
if (!$onlinedata["started"]) {
    $logfile = generateFormattedDate(time());
    file_put_contents("data/logfile.txt", $logfile);
    file_put_contents("logs/" . $logfile . ".log", "");
    include("startup/configcheck.php");
    $onlinedata["started"] = true;
    file_put_contents("online.json", json_encode($onlinedata));
}
include("ratelimiter.php");
include("repair/data/repair.php");
// Retrieve token, username, and identifier from POST fields
$data = json_decode(file_get_contents("php://input"), true);
$token = htmlspecialchars($data['token']);
$username = htmlspecialchars($data['username']);
$identifier = htmlspecialchars($data['identifier']);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://alexidians.com/Super-Diamond-Resourcer/game/server/verify.php");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
    'token' => $token,
    'username' => $username,
    'identifier' => $identifier
)));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
if ($response == "false") {
    echo json_encode(array(
        'success' => false,
        'errorcode' => "ERR_INVALID_SESSION"
    ));
    logMessage("Verification Failed For user " . $username . " (" . $identifier . ") via error code ERR_INVALID_SESSION");
     exit();
}
?>
