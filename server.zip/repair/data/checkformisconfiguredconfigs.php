<?php
// Function to check if JSON is valid
function isConfigValid($json) {
    json_decode($json);
    return (json_last_error() == JSON_ERROR_NONE);
}

// Function to log misconfigured configs
function logMisconfiguredConfig($filename) {
    file_put_contents("repair/misconfiguredconfigs.log", "Misconfigured config: " . $filename, FILE_APPEND);
}
function logConfigStatus($filename, $status) {
    file_put_contents("repair/configstatus.log", $filename . ": " . $status, FILE_APPEND);
}

if($repairconfig["AutoCheckForMisconfiguredConfigs"]) {
file_put_contents("repair/configstatus.log", "");
file_put_contents("repair/misconfiguredconfigs.log", "");
$configs = glob("config/" . "*.json");
foreach ($configs as $config) {
    $configData = file_get_contents($config);
    if (isConfigValid($configData)) {
        logConfigStatus($config, "Configured");
    } else {
        logConfigStatus($config, "Misconfigured");
        logMisconfiguredConfig($config);
    }
}
}
?>
