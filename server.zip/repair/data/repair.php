<?php
 $repairconfig = json_decode(file_get_contents("config/repair.json"), true);
 include("repairplayerdata.php");
 include("checkformisconfiguredconfigs.php");
?>