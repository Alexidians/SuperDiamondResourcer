<?php
function repair_playerdata_ifneeded($identifier) {
    $playerFile = "playerdata/" . $identifier . ".json";
    $referenceFile = "repair/data/playerdata.json";

    // Check if the player file exists
    if (!file_exists($playerFile)) {
        return;
    }

    // Check if the reference file exists
    if (!file_exists($referenceFile)) {
        return;
    }

    // Read the player data
    $playerData = json_decode(file_get_contents($playerFile), true);
    if ($playerData === null && json_last_error() !== JSON_ERROR_NONE) {
        return;
    }

    // Read the reference data
    $referenceData = json_decode(file_get_contents($referenceFile), true);
    if ($referenceData === null && json_last_error() !== JSON_ERROR_NONE) {
        return;
    }

    // Add missing properties from reference data to player data
    foreach ($referenceData as $key => $value) {
        if (!array_key_exists($key, $playerData)) {
            $playerData[$key] = $value;
        }
    }

    // Save the updated player data back to the file
    file_put_contents($playerFile, json_encode($playerData, JSON_PRETTY_PRINT));
}

function repair_all_playerdata_ifneeded() {
    $directory = 'playerdata/';
    $files = glob($directory . '*.json');

    foreach ($files as $file) {
        $identifier = basename($file, '.json');
        add_missing_properties($identifier);
    }
}

if($repairconfig["AutoRepairPlayerData"]) {
 repair_playerdata_ifneeded($identifier);
}
if($repairconfig["AutoRepairAllPlayerData"]) {
 repair_all_playerdata_ifneeded();
}
?>
