#!/bin/bash

# Get the port number from the user
read -p "Enter the port number for the Server: " port

# Define the JSON file path
jsonFile="online.json"

# Update the JSON file to set "online" to true
php -c php.ini -r "file_put_contents('$jsonFile', json_encode(array_merge(json_decode(file_get_contents('$jsonFile'), true), ['online' => true, 'started' => true])));"

# Start the PHP server
php -c php.ini -S localhost:$port &

# Wait for the PHP server to start
sleep 1

# Update the JSON file to set "online" and "started" to false when the server stops
trap 'php -c php.ini -r "file_put_contents('$jsonFile', json_encode(array_merge(json_decode(file_get_contents('$jsonFile'), true), ['online' => false, 'started' => false])));" && exit' INT TERM

# Keep the script running until the PHP server stops
while true; do
    sleep 1
done
