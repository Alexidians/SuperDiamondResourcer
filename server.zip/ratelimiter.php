<?php
// Load rate limit configuration
$config = json_decode(file_get_contents("config/ratelimit.json"), true);

// Check if rate limit configuration is valid
if ($config === null || !isset($config["enable"]) || !isset($config["limit"]) || !isset($config["resettimer"])) {
    echo json_encode(array(
        'success' => false,
        'errorcode' => "ERR_MISCONFIGURED_CONFIG"
    ));
    exit();
}

// Check if rate limiting is enabled
if ($config["enable"]) {
    // Load or initialize request count
    $requests = file_exists("data/ratelimit.int") ? intval(file_get_contents("data/ratelimit.int")) : 0;

    // Increment request count
    $requests++;

    // Save updated request count
    file_put_contents("data/ratelimit.int", $requests);

    // Check if request count exceeds limit
    if ($requests > $config["limit"]) {
        echo json_encode(array(
            'success' => false,
            'errorcode' => "ERR_REQUEST_RATE_LIMITED"
        ));
        logMessage("A request was rate limited.");
        exit();
    }
}

// Reset request count based on modification time of ratelimit.int file
if (isset($config["resettimer"]) && $config["resettimer"] > 0) {
    $last_reset_time = file_exists("data/ratelimit.int") ? filemtime("data/ratelimit.int") : 0;
    $current_time = time();
    if ($current_time - $last_reset_time >= $config["resettimer"]) {
        // Reset request count
        file_put_contents("data/ratelimit.int", 0);
    }
}
?>
