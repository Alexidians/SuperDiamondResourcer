<?php
$data = json_decode(file_get_contents("php://input"));
$token = $data->{"token"};
$username = $data->{"username"};
$identifier = $data->{"identifier"};
include("verify.php");
$drops = json_decode(file_get_contents("config/drops.json"));
$playerdata = json_decode(file_get_contents("playerdata/" . $identifier . ".json"));
$level = $playerdata->{"fishingrodlevel"};
$playerdata->{"fish"} = $playerdata->{"fish"} + ($drops->{"fish"} * $level);
file_put_contents("playerdata/" . $identifier . ".json", json_encode($playerdata));
?>