<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = json_decode(file_get_contents("php://input"));
$token = $data->{"token"};
$username = $data->{"username"};
$identifier = $data->{"identifier"}; // Corrected typo here

include("verify.php");

// Ensure player data is loaded correctly
$playerdata = json_decode(file_get_contents("playerdata/" . $identifier . ".json"));

    // Load upgrade prices and calculate upgrade price
    $upgradeprices = json_decode(file_get_contents("config/upgradeprices.json"));
    $upgradeprice = $upgradeprices->{"pickaxe"} * ($playerdata->{"pickaxelevel"} + $playerdata->{"pickaxelevel"});

    // Check if player has enough coins for the upgrade
    if ($playerdata->{"coins"} >= $upgradeprice) {
        $playerdata->{"coins"} -= $upgradeprice;
        $playerdata->{"pickaxelevel"} += 1;
file_put_contents("playerdata/" . $identifier . ".json", json_encode($playerdata));
        echo "true";
    } else {
        echo "false";
    }
?>
