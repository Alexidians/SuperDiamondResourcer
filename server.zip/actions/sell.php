<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = json_decode(file_get_contents("php://input"));
$token = $data->{"token"};
$username = $data->{"username"};
$identifier = $data->{"identifier"};
include("verify.php");
$playerdata = json_decode(file_get_contents("playerdata/" . $identifier . ".json"));
$incomes = json_decode(file_get_contents("config/incomes.json"));
$earnings = 0;
$earnings = $earnings + ($incomes->{"wood"} * $playerdata->{"wood"});
$playerdata->{"wood"} = 0;
$earnings = $earnings + ($incomes->{"stone"} * $playerdata->{"stone"});
$playerdata->{"stone"} = 0;
$earnings = $earnings + ($incomes->{"crops"} * $playerdata->{"crops"});
$playerdata->{"crops"} = 0;
$earnings = $earnings + ($incomes->{"sand"} * $playerdata->{"sand"});
$playerdata->{"sand"} = 0;
$earnings = $earnings + ($incomes->{"leaves"} * $playerdata->{"leaves"});
$playerdata->{"leaves"} = 0;
$earnings = $earnings + ($incomes->{"fish"} * $playerdata->{"fish"});
$playerdata->{"fish"} = 0;
$playerdata->{"coins"} = $playerdata->{"coins"} + $earnings;
file_put_contents("playerdata/" . $identifier . ".json", json_encode($playerdata));
?>