<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header("Access-Control-Allow-Origin: https://alexidians.com");
header("Access-Control-Allow-Headers: *");

$data = json_decode(file_get_contents("php://input"), true);
$token = htmlspecialchars($data['token']);
$username = htmlspecialchars($data['username']);
$identifier = htmlspecialchars($data['identifier']);

include("verify.php");
logMessage("Connecting User " . $username . " (" . $identifier . ")");
$returnvalue = array(
    "success" => true,
    "mod" => false
);

// Ensure player data file exists or create if not
$playerdataFile = "playerdata/" . $identifier . ".json";
if (!file_exists($playerdataFile)) {
    initializePlayerData($playerdataFile);
}

// Include each script in the modifiers/connect directory
$dir = "modifiers/connect";
$files = scandir($dir);
foreach ($files as $file) {
    if ($file != '.' && $file != '..' && is_file($dir . '/' . $file)) {
        include($dir . '/' . $file);
    }
}

logMessage("Connected User " . $username . " (" . $identifier . ")");

echo json_encode($returnvalue);

// Function to initialize player data and write it to file
function initializePlayerData($playerdataFile) {
    $playerdata = array(
        "coins" => 0,
        "wood" => 0,
        "stone" => 0,
        "crops" => 0,
        "sand" => 0,
        "leaves" => 0,
        "fish" => 0,
        "axelevel" => 1,
        "pickaxelevel" => 1,
        "hoelevel" => 1,
        "shovellevel" => 1,
        "shearslevel" => 1,
        "fishingrodlevel" => 1,
    );
    file_put_contents($playerdataFile, json_encode($playerdata));
}
?>
