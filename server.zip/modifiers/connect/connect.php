<?php
 #this is the connect modifier.
 #here you can also use stuff like "js" to execute clientside code. and "jsconsentmsg" for a custom consent message.
 #here you use $returnval for the return value.
?>