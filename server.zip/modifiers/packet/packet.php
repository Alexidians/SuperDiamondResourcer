<?php
 #this is the packet modifier.
 #use $playerdata for the data of the player.
 #use $packet to modify the packet data.
 #add keys like "js" to the packet to execute clientcode. this will require consent. server can add custom message with "jsconsentmsg".
?>