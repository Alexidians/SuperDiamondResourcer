<?php
// Directory where JSON files are located
$directory = "config/";

// Get all JSON files in the directory
$jsonFiles = glob($directory . "*.json");

// Function to check if JSON is valid
function isJsonValid($json) {
    json_decode($json);
    return (json_last_error() == JSON_ERROR_NONE);
}

// Function to log misconfigured configs
function logMisconfiguredConfig($filename) {
    $date = date("d M Y H:i");
    $logMessage = "[$date] Detected Misconfigured Config: $filename\n";
    file_put_contents("config_check.log", $logMessage, FILE_APPEND);
}

// Iterate through each JSON file and check if it's valid
foreach ($jsonFiles as $file) {
    $jsonContent = file_get_contents($file);
    if (isJsonValid($jsonContent)) {
        echo "$file is a valid JSON file.\n";
    } else {
        echo "$file is not a valid JSON file.\n";
        logMisconfiguredConfig($file);
    }
}
?>
