<?php
 ini_set('display_errors', 1); 
 ini_set('display_startup_errors', 1); 
 error_reporting(E_ALL);
header("Access-Control-Allow-Origin: https://alexidians.com");
header("Access-Control-Allow-Headers: *");

 $data = json_decode(file_get_contents("php://input"), true);
 $token = $data["token"];
 $username = $data["username"];
 $identifier = $data["identifier"];
 include("actions/" . $data["action"] . ".php");
?>